<?php

namespace frontend\controllers;

class LoadingController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

}
